package com.icesofterp.entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;





public class UsersTest {

	public static void main(String[] args) {
		Users user1 = new Users();
		user1.setEmail("aygul.test@gmail.com");
		user1.setFullName("Test Test");
		user1.setPassword("admin8888");
		user1.setStatus(0);
		
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("IceSoftErp");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		entityManager.getTransaction().begin();
		
		entityManager.persist(user1);
		
		entityManager.getTransaction().commit();
		entityManager.close();
		entityManagerFactory.close();
		
		System.out.println("A users object was persisted");
	}

}
