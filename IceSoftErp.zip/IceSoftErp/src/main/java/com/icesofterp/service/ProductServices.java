package com.icesofterp.service;

import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.icesofterp.dao.ProductDAO;
import com.icesofterp.dao.CategoryDAO;
import com.icesofterp.dao.OrderDAO;
import com.icesofterp.entity.Product;
import com.icesofterp.entity.Category;
import static com.icesofterp.service.CommonUtitlity.*;

public class ProductServices {
	private ProductDAO productDAO;
	private CategoryDAO categoryDAO;
	private HttpServletRequest request;
	private HttpServletResponse response;

	public ProductServices(HttpServletRequest request, HttpServletResponse response) {
		this.request = request;
		this.response = response;
		productDAO = new ProductDAO();
		categoryDAO = new CategoryDAO();
	}

	public void listProducts() throws ServletException, IOException {
		listProducts(null);
	}
	
	public void listProducts(String message) throws ServletException, IOException {
		List<Product> listProducts = productDAO.listAll();
		request.setAttribute("listProducts", listProducts);
		
		if (message != null) {
			request.setAttribute("message", message);
		}
		
		forwardToPage("product_list.jsp", message, request, response);
	}
	
	public void showProductNewForm() throws ServletException, IOException {
		List<Category> listCategory = categoryDAO.listAll();
		request.setAttribute("listCategory", listCategory);
		forwardToPage("product_form.jsp", request, response);
	}

	public void createProduct() throws ServletException, IOException {
		String title = request.getParameter("title");
		
		Product existProduct = productDAO.findByTitle(title);
		
		if (existProduct != null) {
			String message = "Could not create new product because the title '"
					+ title + "' already exists.";
			listProducts(message);
			return;
		}
		
		Product newProduct = new Product();
		readProductFields(newProduct);
		
		Product createdProduct = productDAO.create(newProduct);
		
		if (createdProduct.getProductId() > 0) {
			String message = "A new product has been created successfully.";
			listProducts(message);
		}
	}

	public void readProductFields(Product product) throws ServletException, IOException {
		String title = request.getParameter("title");
		String author = request.getParameter("author");
		String description = request.getParameter("description");
		String isbn = request.getParameter("isbn");
		float price = Float.parseFloat(request.getParameter("price"));
		
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date publishDate = null;
		
		try {
			publishDate = dateFormat.parse(request.getParameter("publishDate"));
		} catch (ParseException ex) {
			ex.printStackTrace();
			throw new ServletException("Error parsing publish date (format is MM/dd/yyyy)");
		}
				
		product.setTitle(title);
		product.setAuthor(author);
		product.setDescription(description);
		product.setIsbn(isbn);
		product.setPublishDate(publishDate);
		
		Integer categoryId = Integer.parseInt(request.getParameter("category"));
		Category category = categoryDAO.get(categoryId);
		product.setCategory(category);
		
		product.setPrice(price);
		
		Part part = request.getPart("productImage");
		
		if (part != null && part.getSize() > 0) {
			long size = part.getSize();
			byte[] imageBytes = new byte[(int) size];
			
			InputStream inputStream = part.getInputStream();
			inputStream.read(imageBytes);
			inputStream.close();
			
			product.setImage(imageBytes);
		}
		
	}
	
	public void editProduct() throws ServletException, IOException {
		Integer productId = Integer.parseInt(request.getParameter("id"));
		Product product = productDAO.get(productId);
		
		if (product != null) {
			List<Category> listCategory = categoryDAO.listAll();
			
			request.setAttribute("product", product);
			request.setAttribute("listCategory", listCategory);
			forwardToPage("product_form.jsp", request, response);
		} else {
			String message = "Could not find product with ID " + productId;
			showMessageBackend(message, request, response);			
		}
		
	}

	public void updateProduct() throws ServletException, IOException {
		Integer productId = Integer.parseInt(request.getParameter("productId"));
		String title = request.getParameter("title");
		
		Product existProduct = productDAO.get(productId);
		Product productByTitle = productDAO.findByTitle(title);
		
		if (productByTitle != null && !existProduct.equals(productByTitle)) {
			String message = "Could not update product because there's another product having same title.";
			listProducts(message);
			return;
		}
		
		readProductFields(existProduct);
		
		productDAO.update(existProduct);
		
		String message = "The product has been updated successfully.";
		listProducts(message);
	}

	public void deleteProduct() throws ServletException, IOException {
		Integer productId = Integer.parseInt(request.getParameter("id"));
		Product product =  productDAO.get(productId);
		
		if (product == null) {
			String message = "Could not find product with ID " + productId 
					+ ", or it might have been deleted";
			showMessageBackend(message, request, response);
			
		} else {			
			if (!product.getReviews().isEmpty()) {
				String message = "Could not delete the product with ID " + productId
						+ " because it has reviews";
				showMessageBackend(message, request, response);
			} else {
				OrderDAO orderDAO = new OrderDAO();
				long countByOrder = orderDAO.countOrderDetailByProduct(productId);
				
				if (countByOrder > 0) {
					String message = "Could not delete product with ID " + productId
							+ " because there are orders associated with it.";
					showMessageBackend(message, request, response);
				} else {
					String message = "The product has been deleted successfully.";
					productDAO.delete(productId);			
					listProducts(message);
				}
			}
		}
	}

	public void listProductsByCategory() throws ServletException, IOException {
		int categoryId = Integer.parseInt(request.getParameter("id"));
		Category category = categoryDAO.get(categoryId);
		
		if (category == null) {
			String message = "Sorry, the category ID " + categoryId + " is not available.";
			showMessageFrontend(message, request, response);			
			return;
		}
		
		List<Product> listProducts = productDAO.listByCategory(categoryId);
		
		request.setAttribute("listProducts", listProducts);
		request.setAttribute("category", category);
		
		forwardToPage("frontend/products_list_by_category.jsp", request, response);	
	}

	public void viewProductDetail() throws ServletException, IOException {
		Integer productId = Integer.parseInt(request.getParameter("id"));
		Product product = productDAO.get(productId);
		
		if (product != null) {
			request.setAttribute("product", product);
			forwardToPage("frontend/product_detail.jsp", request, response);
		} else {			
			String message = "Sorry, the product with ID " + productId + " is not available.";
			showMessageFrontend(message, request, response);			
		}
	}

	public void search() throws ServletException, IOException {
		String keyword = request.getParameter("keyword");
		List<Product> result = null; 
				
		if (keyword.equals("")) {
			result = productDAO.listAll();
		} else {
			result = productDAO.search(keyword);
		}
		
		request.setAttribute("keyword", keyword);
		request.setAttribute("result", result);
		forwardToPage("frontend/search_result.jsp", request, response);
	}
}
