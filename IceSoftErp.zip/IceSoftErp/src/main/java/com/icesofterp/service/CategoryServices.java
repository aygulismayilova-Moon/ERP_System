package com.icesofterp.service;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.icesofterp.dao.CategoryDAO;
import com.icesofterp.entity.Category;

public class CategoryServices {
	private CategoryDAO categoryDAO;
	private HttpServletRequest request;
	private HttpServletResponse response;
	
	public CategoryServices(HttpServletRequest request, HttpServletResponse response) {
		this.request = request;
		this.response = response;
		
		categoryDAO = new CategoryDAO();
	}
	
	public void listCategory(String message) throws ServletException, IOException {
		List<Category> listCategory =categoryDAO.listAll();
		request.setAttribute("listCategory",listCategory);
		if(message!=null) {
			request.setAttribute("message", message);
		}

		String listPage="category_list.jsp";
		RequestDispatcher requestDispatcher=request.getRequestDispatcher(listPage);
		requestDispatcher.forward(request, response);
		
	}
	
	public void listCategory() throws ServletException, IOException {
		listCategory(null);
	}
	
	public void createCategory() throws ServletException, IOException {
		String code = request.getParameter("code");
		String name = request.getParameter("name");
		Category existCategory = categoryDAO.findByName(name);
		Category existCategoryCode = categoryDAO.findByCode(code);
		
		if(existCategory!=null) {
			String message="Could not create category. "+
		"A category with name "+name+" already exist.";
			request.setAttribute("message", message);
			RequestDispatcher requestDispatcher=request.getRequestDispatcher("message.jsp");
			requestDispatcher.forward(request, response);
		} else if(existCategoryCode!=null) {
			String message="Could not create category. "+
		"A category with code "+code+" already exist.";
			request.setAttribute("message", message);
			RequestDispatcher requestDispatcher=request.getRequestDispatcher("message.jsp");
			requestDispatcher.forward(request, response);
		} 
		
		else {
			Category newCategory=new Category(code,name);
			categoryDAO.create(newCategory);
			String message="New category created successfully.";
			listCategory(message);
		}
		
	}
	
	public void editCategory() throws ServletException, IOException {
		int categoryId = Integer.parseInt(request.getParameter("id"));
		Category category=categoryDAO.get(categoryId);
		//request.setAttribute("category", category);
		String editPage = "category_form.jsp";
		
		if (category != null) {
			request.setAttribute("category", category);	
		} else {
			String message = "Could not find category with ID " + categoryId;
			request.setAttribute("message", message);
			editPage = "message.jsp";
		}			
		
		RequestDispatcher requestDispatcher=request.getRequestDispatcher(editPage);
		requestDispatcher.forward(request, response);
		
		
	}

	public void updateCategory() throws ServletException, IOException {
		
		int categoryId = Integer.parseInt(request.getParameter("categoryId"));
		String categoryName = request.getParameter("name");
		String categoryCode = request.getParameter("code");
		
		Category categoryById = categoryDAO.get(categoryId);
		Category categoryByCode = categoryDAO.findByCode(categoryCode);
		Category categoryByName = categoryDAO.findByName(categoryName);
		
		if(categoryByName != null && categoryById.getCategoryId() != categoryByName.getCategoryId()) {
			String message="Could not update category."
					+" A category with name "+categoryName+" already exists.";
			request.setAttribute("message", message);
			RequestDispatcher requestDispatcher=request.getRequestDispatcher("message.jsp");
			requestDispatcher.forward(request, response);
		} else 	if(categoryByCode != null && categoryById.getCategoryId() != categoryByCode.getCategoryId()) {
			String message="Could not update category."
					+" A category with code "+categoryCode+" already exists.";
			request.setAttribute("message", message);
			RequestDispatcher requestDispatcher=request.getRequestDispatcher("message.jsp");
			requestDispatcher.forward(request, response);
		}
		
		else {
			categoryById.setCode(categoryCode);
			categoryById.setName(categoryName);
			categoryDAO.update(categoryById);
			String message = "Category has been updated successfully.";
			listCategory(message);
		}
	}

	public void deleteCategory() throws ServletException, IOException {
		int categoryId = Integer.parseInt(request.getParameter("id"));
		categoryDAO.delete(categoryId);
		String message ="The category with ID "+categoryId+" has been removed successfully.";
		listCategory(message);
	}
	
	
}
