package com.icesofterp.dao;

import java.awt.print.Book;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import com.icesofterp.entity.Product;

public class ProductDAO extends JpaDAO<Product> implements GenericDAO<Product> {

	public ProductDAO() {
	}

	@Override
	public Product create(Product product) {
		product.setLastUpdateTime(new Date());
		return super.create(product);
	}

	@Override
	public Product update(Product product) {
		product.setLastUpdateTime(new Date());
		return super.update(product);
	}

	@Override
	public Product get(Object productId) {
		return super.find(Product.class, productId);
	}

	@Override
	public void delete(Object productId) {
		super.delete(Product.class, productId);
		
	}
	

	@Override
	public List<Product> listAll() {
		return super.findWithNamedQuery("Product.findAll");
	}
	
	public Product findByTitle(String title) {
		List<Product> result = super.findWithNamedQuery("Product.findByTitle","title",title);
		if(result.isEmpty()) {
			return result.get(0);
		}
		return null;
	}

	@Override
	public long count() {
		return super.countWithNamedQuery("Product.countAll");
	}

	public List<Product> listByCategory(int categoryId) {
		return super.findWithNamedQuery("Product.findByCategory", "catId", categoryId);
	}

	public List<Product> search(String keyword) {
		return super.findWithNamedQuery("Product.search", "keyword", keyword);
	}
	
	public List<Product> listNewProduct() {		
		return super.findWithNamedQuery("Product.listNew", 0, 4);
	}

	public List<Product> listBestSellingProduct() {
		return super.findWithNamedQuery("OrderDetail.bestSelling", 0, 4);
	}

	public List<Product> listMostFavoredProduct() {

			List<Product> mostFavoredProduct = new ArrayList<>();
			
			List<Object[]> result = super.findWithNamedQueryObjects("Review.mostFavoredProduct", 0, 4);
			
			if (!result.isEmpty()) {
				for (Object[] elements : result) {
					Product product = (Product) elements[0];
					mostFavoredProduct.add(product);
				}
			} 
			
			return mostFavoredProduct;
		}


	

}
