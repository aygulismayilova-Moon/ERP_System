package com.icesofterp.controller.admin.order;


import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.icesofterp.dao.ProductDAO;
import com.icesofterp.entity.Product;
import com.icesofterp.entity.ProductOrder;
import com.icesofterp.entity.OrderDetail;

@WebServlet("/admin/add_product_to_order")
public class AddProductToOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public AddProductToOrderServlet() {
		super();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int productId = Integer.parseInt(request.getParameter("productId"));
		int quantity = Integer.parseInt(request.getParameter("quantity"));
		
		ProductDAO productDao = new ProductDAO();
		Product product = productDao.get(productId);
		
		HttpSession session = request.getSession();
		ProductOrder order = (ProductOrder) session.getAttribute("order");
		
		float subtotal = quantity * product.getPrice();
		
		OrderDetail orderDetail = new OrderDetail();
		orderDetail.setProduct(product);
		orderDetail.setQuantity(quantity);
		orderDetail.setSubtotal(subtotal);
		
		float newTotal = order.getTotal() + subtotal;
		order.setTotal(newTotal);
		
		order.getOrderDetails().add(orderDetail);
		
		request.setAttribute("product", product);
		session.setAttribute("NewProductPendingToAddToOrder", true);
		
		String resultPage = "add_product_result.jsp";
		RequestDispatcher dispatcher = request.getRequestDispatcher(resultPage);
		dispatcher.forward(request, response);
	}

}
