package com.icesofterp.controller.frontend;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.icesofterp.dao.ProductDAO;
import com.icesofterp.entity.Product;

@WebServlet("")
public class HomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public HomeServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ProductDAO productDAO = new ProductDAO();
		
		List<Product> listNewProduct = productDAO.listNewProduct();
		List<Product> listBestSellingProduct = productDAO.listBestSellingProduct();
		List<Product> listFavoredProduct = productDAO.listMostFavoredProduct();
		
		request.setAttribute("listNewProduct", listNewProduct);
		request.setAttribute("listBestSellingProduct", listBestSellingProduct);
		request.setAttribute("listFavoredProduct", listFavoredProduct);
		
		String homepage = "frontend/index.jsp";
		RequestDispatcher dispatcher = request.getRequestDispatcher(homepage);
		dispatcher.forward(request, response);
	}

}
