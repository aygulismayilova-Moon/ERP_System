package com.icesofterp.controller.admin.order;


import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.icesofterp.dao.ProductDAO;
import com.icesofterp.entity.Product;

@WebServlet("/admin/add_product_form")
public class ShowAddProductFormServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ShowAddProductFormServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ProductDAO productDao = new ProductDAO();
		List<Product> listProduct = productDao.listAll();
		request.setAttribute("listProduct", listProduct);
		
		String addFormPage = "add_product_form.jsp";
		RequestDispatcher dispatcher = request.getRequestDispatcher(addFormPage);
		dispatcher.forward(request, response);
		
	}

}
