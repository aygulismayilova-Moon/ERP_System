package com.icesofterp.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
//import javax.persistence.Table;
//import javax.persistence.Table;
import javax.persistence.Table;

@Entity
@Table(name = "users", catalog = "icesofterpdb")
@NamedQueries({
		@NamedQuery(name="Users.findAll", query="SELECT u FROM Users u Order by u.fullName"),
		@NamedQuery(name="Users.findByEmail", query="SELECT u FROM Users u WHERE u.email= :email"),
		@NamedQuery(name="Users.findByPhone", query="SELECT u FROM Users u WHERE u.phone= :userPhone"),
		@NamedQuery(name="Users.findByPhoto", query="SELECT u FROM Users u WHERE u.photo= :userPhoto"),
		@NamedQuery(name="Users.findByStatus", query="SELECT u FROM Users u WHERE u.status= :status"),
		@NamedQuery(name="Users.countAll", query="SELECT COUNT(u) FROM Users u"),
		@NamedQuery(name="Users.checkLogin", query="SELECT u FROM Users u WHERE u.email= :email AND u.password= :password")
		
}
		)
//@Table(name = "users")
public class Users {
	private Integer userId;
	private String email;
	private String fullName;
	private String password;
	private Integer status;
	private String photo;
	private String phone;
	
	
	
	public Users() {
		// TODO Auto-generated constructor stub
	}
	
	public Users(Integer userId,String email, String fullName, String password, Integer status, String photo, String phone) {
		this(email , fullName, password, status, photo,phone);
		this.userId=userId;
	//	this.status=status;
	}

	public Users(String email, String fullName, String password, Integer status, String photo, String phone) {
		super();
		this.email = email;
		this.fullName = fullName;
		this.password = password;
		this.status = status;
		this.photo = photo;
		this.phone = phone;
	}

	@Column(name="user_id")
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	
	@Column(name="photo")
	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}
	

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name="full_name")
	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
		
	}
	
	@Column(name="phone")
	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

}
