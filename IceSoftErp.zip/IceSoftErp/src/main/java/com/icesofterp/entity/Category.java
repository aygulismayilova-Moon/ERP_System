package com.icesofterp.entity;



	// Generated May 22, 2018 5:46:15 AM by Hibernate Tools 5.2.10.Final

	import java.util.HashSet;
	import java.util.Set;
	import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.FetchType;
	import javax.persistence.GeneratedValue;
	import static javax.persistence.GenerationType.IDENTITY;
	import javax.persistence.Id;
	import javax.persistence.NamedQueries;
	import javax.persistence.NamedQuery;
	import javax.persistence.OneToMany;
	import javax.persistence.Table;

	@Entity
	@Table(name = "category", catalog = "icesofterpdb")
	@NamedQueries({
		@NamedQuery(name = "Category.findAll", query = "SELECT c FROM Category c ORDER BY c.name"),
		@NamedQuery(name = "Category.countAll", query = "SELECT COUNT(c) FROM Category c"),
		@NamedQuery(name = "Category.findByName", query = "SELECT c FROM Category c WHERE c.name = :name"),
		@NamedQuery(name = "Category.findByCode", query = "SELECT c FROM Category c WHERE c.code = :code")
	})
	public class Category  implements java.io.Serializable {

		private Integer categoryId;
		private String code;
		private String name;
		private Set<Product> product = new HashSet<Product>(0);

		public Category() {
		}

		public Category(String code,String name) {
			this.code = code;
			this.name = name;
		}

		public Category(String code,String name, Set<Product> product) {
			this.code = code;
			this.name = name;
			this.product = product;
		}

		@Id
		@GeneratedValue(strategy = IDENTITY)

		@Column(name = "category_id", unique = true, nullable = false)
		public Integer getCategoryId() {
			return this.categoryId;
		}

		public void setCategoryId(Integer categoryId) {
			this.categoryId = categoryId;
		}

		@Column(name = "name", nullable = false, length = 30)
		public String getName() {
			return this.name;
		}

		public void setName(String name) {
			this.name = name;
		}
		
		@Column(name = "code")
		public String getCode() {
			return this.code;
		}

		public void setCode(String code) {
			this.code = code;
		}

		@OneToMany(fetch = FetchType.LAZY, mappedBy = "category")
		public Set<Product> getItems() {
			return this.product;
		}

		public void setItems(Set<Product> product) {
			this.product = product;
		}

	
}
