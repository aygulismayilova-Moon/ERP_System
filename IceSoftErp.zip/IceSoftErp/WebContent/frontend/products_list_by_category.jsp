<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>    
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Products in ${category.name} - Online Products Store</title>
<link rel="stylesheet" href="css/style.css" >
</head>
<body>
	<jsp:directive.include file="header.jsp" />
	
	<div class="center">
		<h2>${category.name}</h2>
	</div>
	
	<div class="product-group">
		<c:forEach items="${listProducts}" var="product">
			<div class="product">
				<div>
					<a href="view_product?id=${product.productId}">
						<img class="product-small" src="data:image/jpg;base64,${product.base64Image}" />
					</a>
				</div>
				<div>
					<a href="view_product?id=${product.productId}">
						<b>${product.title}</b>
					</a>
				</div>
				<div>
					<jsp:directive.include file="product_rating.jsp" />				
				</div>
				<div><i>by ${product.author}</i></div>
				<div><b>$${product.price}</b></div>
			</div>
			
		</c:forEach>
	</div>
	
	<jsp:directive.include file="footer.jsp" />
</body>
</html>