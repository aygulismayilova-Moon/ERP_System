<div class="product">
	<div>
		<a href="view_product?id=${product.productId}"> 
		<img class="product-small"
			src="data:image/jpg;base64,${product.base64Image}" />
		</a>
	</div>
	<div>
		<a href="view_product?id=${product.productId}"> <b>${product.title}</b>
		</a>
	</div>
	<div>
		<jsp:directive.include file="product_rating.jsp" />				
	</div>
	<div>
		<i>by ${product.author}</i>
	</div>
	<div>
		<b>$${product.price}</b>
	</div>
</div>