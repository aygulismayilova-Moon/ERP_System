<div align="center">
<h4>Ice-Soft Administration</h4>
<h4>Copyright &copy; by Ice-Soft Co.</h4>
</div>