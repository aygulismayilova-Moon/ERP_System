<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<div align="center">
	<div>
		<a href="${pageContext.request.contextPath}">
			<img src="../images/IceSoftErpLogo.png" alt="image" height="150" width="180"/>
		</a>
	</div>
	<div>
		Welcome, <c:out value="${sessionScope.useremail}" /> | <a href="logout">Logout</a>
		<br/><br/>
	</div>
	<div id="headermenu">
		<div>
			<a href="list_users">
				<img src="../images/users.png" alt="image" height="50" width="60"/><br/>Users
			</a>
		</div>
		<div>
			<a href="list_category">
				<img src="../images/category.jpg" alt="image" height="50" width="60"/><br/>Categories
			</a>
		</div>
		<div>
			<a href="list_products">
				<img src="../images/product.jpg" alt="image" height="50" width="60"/><br/>Products
			</a>
		</div>
		<div>
			<a href="list_customer">
				<img src="../images/customer.png" alt="image" height="50" width="60"/><br/>Customers
			</a>
		</div>
		<div>
			<a href="list_review">
				<img src="../images/review.png" alt="image" height="50" width="60"/><br/>Reviews
			</a>
		</div>
		<div>
			<a href="list_order"><img src="../images/order.png" alt="image" height="50" width="60"/><br/>
				Orders
			</a>
		</div>
		<div>
			<a href="list_branch"><img src="../images/branch.png" alt="image" height="50" width="60"/><br/>
				Branches
			</a>
		</div>
		<div>
			<a href="list_warehouse"><img src="../images/warehouses.jpg" alt="image" height="50" width="60"/><br/>
				Warehouses
			</a>
		</div>
		<div>
			<a href="list_supplier"><img src="../images/supplier.png" alt="image" height="50" width="60"/><br/>
				Suppliers
			</a>
		</div>
		<div>
			<a href="list_area"><img src="../images/area.jpg" alt="image" height="50" width="60"/><br/>
				Areas
			</a>
		</div>
	</div>
</div>